const { badRequest } = require("../utils/errors");

function isValidEmail(email) {
  if (typeof email !== "string") return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function validatePassword(password) {
  const issues = [];
  if (typeof password !== "string") {
    issues.push("password must be a string");
    return issues;
  }
  if (password.length < 8) issues.push("password must be at least 8 characters");
  if (!/[A-Z]/.test(password)) issues.push("password must include an uppercase letter");
  if (!/[a-z]/.test(password)) issues.push("password must include a lowercase letter");
  if (!/[0-9]/.test(password)) issues.push("password must include a number");
  if (!/[^A-Za-z0-9]/.test(password)) issues.push("password must include a symbol");
  return issues;
}

function validateCreateUser(body) {
  const details = [];

  const email = body?.email;
  const password = body?.password;

  if (!email) details.push("email is required");
  else if (!isValidEmail(email)) details.push("email format is invalid");

  if (!password) details.push("password is required");
  else details.push(...validatePassword(password));

  if (details.length > 0) {
    return badRequest("Validation failed", details);
  }

  return { ok: true, value: { email: email.trim(), password } };
}

module.exports = { validateCreateUser };
