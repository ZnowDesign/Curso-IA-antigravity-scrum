# demo-fix

Este escenario corresponde a la versión correcta.

Ejecuta:
```bash
npm install
npm run test:cov
```
Esperado: CI local pasa y coverage cumple.
