# Scenarios (Recording Aids)

Estos escenarios se incluyen para grabación didáctica.

- `demo-fail/` contiene un bug intencional para mostrar supervisión + pruebas fallando.
- `demo-fix/` contiene la versión corregida.

## Uso sugerido en grabación
1) Ejecuta tests en `demo-fail` → falla.
2) Explica por qué falló y cómo lo detecta CI.
3) Aplica corrección (o cambia a `demo-fix`) → pasa.

Comandos:
```bash
cd scenarios/demo-fail
npm install
npm run test:cov
```
