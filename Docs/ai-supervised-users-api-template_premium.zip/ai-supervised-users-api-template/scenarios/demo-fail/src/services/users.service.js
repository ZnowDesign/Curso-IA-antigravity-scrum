const crypto = require("crypto");

/**
 * Demo in-memory user creator (no DB) to focus on validation + testing + supervised workflow.
 */
function createUser({ email }) {
  const id = crypto.randomUUID();
  return {
    id,
    email,
    createdAt: new Date().toISOString()
  };
}

module.exports = { createUser };
