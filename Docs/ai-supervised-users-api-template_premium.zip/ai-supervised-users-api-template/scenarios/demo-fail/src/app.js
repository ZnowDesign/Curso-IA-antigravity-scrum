const express = require("express");
const usersRoutes = require("./routes/users.routes");

function createApp() {
  const app = express();
  app.use(express.json());

  app.use("/api", usersRoutes);

  app.use((req, res) =>
    res.status(404).json({ error: { code: "NOT_FOUND", message: "Not found" } })
  );

  return app;
}

module.exports = { createApp };
