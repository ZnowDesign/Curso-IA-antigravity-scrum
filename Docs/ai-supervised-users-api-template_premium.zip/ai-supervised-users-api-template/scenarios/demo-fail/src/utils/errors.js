function badRequest(message, details = []) {
  return {
    status: 400,
    body: {
      error: {
        code: "BAD_REQUEST",
        message,
        details
      }
    }
  };
}

module.exports = { badRequest };
