const express = require("express");
const { validateCreateUser } = require("../validators/users.validator");
const { createUser } = require("../services/users.service");

const router = express.Router();

router.post("/users", (req, res) => {
  const result = validateCreateUser(req.body);

  if (!result.ok) {
    return res.status(result.status).json(result.body);
  }

  const user = createUser(result.value);
  return res.status(201).json(user);
});

module.exports = router;
