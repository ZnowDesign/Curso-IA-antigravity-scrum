# demo-fail (intencional)

Este escenario tiene un bug intencional: se deshabilitó la validación de símbolo en password.

Objetivo en grabación:
- Mostrar que la IA puede omitir reglas si no se audita.
- Mostrar que tests + coverage detectan el problema.

Ejecuta:
```bash
npm install
npm run test:cov
```
Esperado: tests fallan.
