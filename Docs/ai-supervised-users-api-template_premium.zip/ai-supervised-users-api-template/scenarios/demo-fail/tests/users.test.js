const request = require("supertest");
const { createApp } = require("../src/app");

describe("POST /api/users", () => {
  const app = createApp();

  test("201 - creates user with valid payload", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ email: "dev@example.com", password: "Str0ngPass!" });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("id");
    expect(res.body).toMatchObject({ email: "dev@example.com" });
    expect(res.body).toHaveProperty("createdAt");
  });

  test("400 - missing email", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ password: "Str0ngPass!" });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("BAD_REQUEST");
    expect(res.body.error.details).toContain("email is required");
  });

  test("400 - invalid email format", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ email: "nope", password: "Str0ngPass!" });

    expect(res.status).toBe(400);
    expect(res.body.error.details).toContain("email format is invalid");
  });

  test("400 - weak password (multiple issues)", async () => {
    const res = await request(app)
      .post("/api/users")
      .send({ email: "dev@example.com", password: "abc" });

    expect(res.status).toBe(400);
    expect(res.body.error.details).toContain("password must be at least 8 characters");
    expect(res.body.error.details).toContain("password must include an uppercase letter");
    expect(res.body.error.details).toContain("password must include a number");
    expect(res.body.error.details).toContain("password must include a symbol");
  });
});
