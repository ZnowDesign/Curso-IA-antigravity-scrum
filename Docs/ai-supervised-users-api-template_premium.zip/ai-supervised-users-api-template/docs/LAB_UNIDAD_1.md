# Laboratorio – Unidad 1 (Template)

## Objetivo
Aplicar el flujo **Plan-first (Antigravity)** para delegar implementación a un agente y validarla con **tests + coverage + CI**.

## Setup
- Node.js 18+
- `npm install`

## Pasos
1. Lee `docs/PROMPTS_UNIDAD_1.md`.
2. Define tu plan técnico (contrato, validaciones, criterios).
3. Ejecuta el prompt en tu herramienta de agente.
4. Compara resultado con este template.
5. Corre:
   - `npm test`
   - `npm run test:cov`
6. Ajusta algo en validaciones y agrega un test adicional.

## Criterios de aceptación
- Coverage global ≥ 70%
- Tests pasando
- Separación de responsabilidades
- README actualizado si cambias comportamiento

## Troubleshooting
- Si coverage falla: agrega tests o elimina código no ejecutado.
- Si tests son frágiles: mejora asserts y casos.
