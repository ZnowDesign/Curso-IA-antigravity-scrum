# ADR-XXXX: <Título de la decisión>

Fecha: YYYY-MM-DD  
Estado: Propuesto | Aceptado | Rechazado | Deprecado  
Autor: <Nombre>

---

## Contexto
Describe el problema, restricciones y por qué se necesita una decisión.

## Decisión
Describe la decisión tomada de forma clara y verificable.

## Alternativas Consideradas
- Opción A: pros / contras
- Opción B: pros / contras

## Consecuencias
Impactos esperados (técnicos, operativos, de seguridad, de mantenimiento).

## Evidencia / Métricas
- Coverage objetivo:
- Métricas CI:
- Resultados de pruebas:

## Seguimiento
Qué tareas o cambios derivan de esta decisión.
