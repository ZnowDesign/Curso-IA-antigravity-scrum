# Prompts – Unidad 1

## Prompt maestro (Plan-first)

```text
Actúa como desarrollador senior. Genera un API en Node.js con Express.

Objetivo: Implementar POST /users con validación robusta.
Reglas:
- No usar librerías externas de validación.
- Validar email requerido y formato básico.
- Validar password requerido, min 8, al menos 1 mayúscula, 1 minúscula, 1 número, 1 símbolo.
- Responder 201 con { id, email, createdAt } cuando es válido.
- Responder 400 con JSON { error: { code, message, details } } cuando falla validación.
- Separar responsabilidades: routes, validators, services, utils.
- Incluir tests con Jest + Supertest cubriendo casos válidos e inválidos.
- Cumplir coverage mínimo 70%.

Entrega:
- Estructura de archivos sugerida
- Código completo por archivo
- Comandos para ejecutar tests y coverage
```

## Prompt de auditoría (revisión)

```text
Revisa el siguiente código como Tech Lead.
1) Señala riesgos (seguridad, mantenibilidad, duplicación).
2) Verifica cumplimiento de criterios de aceptación.
3) Propón refactor mínimo (no reescribir todo).
4) Propón tests adicionales que aumenten cobertura.
Devuelve una checklist accionable.
```

## Prompt de iteración (corrección)

```text
Corrige SOLO lo necesario para cumplir:
- coverage ≥ 70%
- modelo de error consistente
- validaciones completas

Entrega un diff por archivo.
```
