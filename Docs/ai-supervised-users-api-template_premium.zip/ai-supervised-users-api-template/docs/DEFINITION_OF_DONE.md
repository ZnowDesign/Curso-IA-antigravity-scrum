# Definition of Done (DoD)

Una historia está **Done** cuando:

- Código implementado y revisado.
- Tests automatizados cubren casos críticos.
- Coverage global ≥ 70% (o el gate definido).
- CI verde (tests + coverage).
- Lint sin errores críticos.
- Documentación mínima actualizada (README / notas técnicas).
- No hay secretos/keys en repositorio.

Checklist:
- [ ] PR aprobado
- [ ] Tests passing
- [ ] Coverage OK
- [ ] CI verde
- [ ] Lint OK
- [ ] Docs actualizadas
