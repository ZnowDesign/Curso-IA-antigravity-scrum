# Definition of Ready (DoR)

Una historia está **Ready** cuando:

- Tiene descripción clara de usuario/valor.
- Incluye criterios de aceptación verificables.
- Define inputs/outputs y casos límite relevantes.
- Define restricciones (seguridad, compatibilidad, calidad).
- Incluye plan de pruebas mínimo (qué se va a probar).
- Se puede dividir en tareas realizables dentro del sprint.
- No depende de información faltante.

Checklist:
- [ ] Historia escrita
- [ ] Criterios de aceptación
- [ ] Edge cases
- [ ] Restricciones
- [ ] Plan de pruebas
- [ ] Tareas estimables
