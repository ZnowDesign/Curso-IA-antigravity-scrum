# AI-Supervised Users API (Unit 1 Template)

This repository is a **ready-to-record demo template** for **Unit 1** of the course:
**"Desarrollo de Software con IA y Agentes Autónomos bajo Scrum"**.

## What this template demonstrates
- Plan-first workflow (Antigravity)
- Prompt structure with constraints + acceptance criteria
- Separation of concerns (routes / validators / services / utils)
- Automated testing with Jest + Supertest
- Coverage as a quality gate (≥ 70%)
- CI pipeline (GitHub Actions) running tests + coverage

---

## Quickstart

### 1) Install
```bash
npm install
```

### 2) Run tests
```bash
npm test
```

### 3) Run coverage gate
```bash
npm run test:cov
```

### 4) Run server
```bash
npm start
```

Server: `http://localhost:3000`
Endpoint: `POST http://localhost:3000/api/users`

Body:
```json
{ "email": "dev@example.com", "password": "Str0ngPass!" }
```

---

## Recording notes (recommended)
- Show the **plan** and acceptance criteria before generating.
- Show **prompt** with constraints.
- Generate code, then **audit**.
- Run `npm run test:cov` and show the report.

---

## License
Educational template.


---

## Premium additions (recording aids)
- `docs/ADR_TEMPLATE.md`
- `docs/DEFINITION_OF_READY.md`
- `docs/DEFINITION_OF_DONE.md`
- `scenarios/` (demo-fail + demo-fix for on-camera supervision)
