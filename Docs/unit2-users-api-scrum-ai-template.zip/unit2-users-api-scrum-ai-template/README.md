# Unidad 2 – Users API (Scrum + IA + Agentes) — Template

Este repositorio es el **template descargable** para la **demo técnica de la Unidad 2** del curso:
**Desarrollo de Software con IA y Agentes Autónomos bajo Scrum**.

## Objetivo
Demostrar un **Sprint simulado** con:
- Planificación Scrum (Backlog + DoR/DoD)
- Delegación a agentes (prompts)
- Supervisión técnica
- Validación automática (tests + coverage)
- CI en GitHub Actions

## Requisitos
- Node.js **18+**
- npm
- Git

## Instalación
```bash
npm install
```

## Ejecutar pruebas
```bash
npm test
npm run test:cov
```

## Ejecutar la API
```bash
npm start
```
Por defecto escucha en `http://localhost:3000`

## Endpoints
- `GET /users`
- `POST /users` con body JSON `{ "email": "...", "password": "..." }`

## Evidencias (para la demo)
- Sprint Backlog: `docs/SPRINT.md`
- Prompts usados: `docs/PROMPTS.md`
- Retrospective: `docs/RETRO.md`
- Workflow CI: `.github/workflows/ci.yml`

## Definition of Done (DoD) mínimo
- CI verde
- Coverage **≥ 70%**
- Documentación actualizada
- Evidencia de supervisión IA (prompts + decisiones)

---
> Nota: Este template no contiene secretos. No pegues API keys en el repo.
