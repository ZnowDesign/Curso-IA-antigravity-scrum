# Retro Sprint 1

## Qué funcionó
- Prompts con restricciones redujeron iteraciones.
- CI forzó DoD real.

## Qué falló / riesgos
- Primera versión no cubrió payload incompleto.
- Necesitamos estandarizar DoR para historias delegables.

## Acciones para el siguiente sprint
- Plantilla fija de historia + criterios + restricciones.
- Añadir lint y security scan ligero.
