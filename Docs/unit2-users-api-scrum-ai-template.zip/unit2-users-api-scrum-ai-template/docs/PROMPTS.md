# PROMPTS – Unidad 2 (Demo Sprint Simulado)

> Aquí se registran los prompts utilizados y sus iteraciones.
> En grabación: muestra este archivo para evidenciar supervisión.

## Prompt 1 — validateUser + tests
(Coloca aquí el prompt exacto usado)

## Prompt 2 — Express API + tests
(Coloca aquí el prompt exacto usado)

## Prompt 3 — completar coverage / edge cases
(Coloca aquí el prompt exacto usado)

## Notas de supervisión
- Qué se aceptó y por qué
- Qué se rechazó y por qué
- Qué cambió entre iteraciones
