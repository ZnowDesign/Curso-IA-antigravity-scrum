# Demo Runbook – Unidad 2

## Objetivo
Mostrar Scrum + IA + CI en un Sprint simulado.

## Pasos rápidos (para grabación)
1) Mostrar `docs/SPRINT.md` (Planning)
2) Mostrar DoR/DoD (mismo doc)
3) Ejecutar `npm run test:cov` (antes)
4) Mostrar prompts en `docs/PROMPTS.md`
5) Ejecutar tests + coverage (después)
6) Mostrar workflow CI verde en GitHub Actions
7) Probar endpoints (curl)
8) Mostrar `docs/RETRO.md` (cierre)

## Comandos útiles
```bash
npm install
npm run test:cov
npm start
```
