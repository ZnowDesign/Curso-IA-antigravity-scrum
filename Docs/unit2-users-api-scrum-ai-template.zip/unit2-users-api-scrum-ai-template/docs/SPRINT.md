# Sprint 1 – Users API (AI-Supervised)

## Objetivo del Sprint
Entregar Users API mínima con calidad verificable (**CI + coverage ≥70%**).

## Definition of Ready (DoR)
Una historia está lista si:
- Alcance delimitado técnicamente
- Restricciones explícitas
- Criterios de aceptación medibles
- Delegación a agente definida (qué sí / qué no)

## Definition of Done (DoD)
Una historia está terminada si:
- CI verde
- Coverage ≥ 70%
- Tests relevantes
- Documentación actualizada
- Evidencia de supervisión IA (prompts + decisiones)

## Historias
1) GET /users
   - AC: retorna arreglo JSON (in-memory)
   - DoD: tests + CI verde + coverage ≥70%

2) POST /users
   - AC: crea usuario en memoria con validación
   - DoD: tests + CI verde + coverage ≥70%

3) Validación validateUser(email, password)
   - AC: email válido, password min 8, 1 número, 1 símbolo
   - DoD: tests unitarios + coverage ≥70%
