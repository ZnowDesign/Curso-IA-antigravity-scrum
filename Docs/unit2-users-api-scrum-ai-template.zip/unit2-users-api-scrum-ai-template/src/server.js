const express = require("express");
const { validateUser } = require("./validators/validateUser");

const app = express();
app.use(express.json());

// In-memory store (solo para demo)
const users = [];

app.get("/users", (req, res) => {
  res.status(200).json(users);
});

app.post("/users", (req, res) => {
  const { email, password } = req.body || {};

  const result = validateUser(email, password);
  if (!result.ok) {
    return res.status(400).json({ errors: result.errors });
  }

  const user = { id: users.length + 1, email };
  users.push(user);
  return res.status(201).json(user);
});

// Arranque standalone (para demo)
if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Users API listening on http://localhost:${port}`);
  });
}

module.exports = { app, users };
