/**
 * validateUser(email, password)
 * Reglas:
 * - Email con regex razonable
 * - Password mínimo 8 caracteres
 * - Al menos 1 número
 * - Al menos 1 símbolo
 *
 * @param {string} email
 * @param {string} password
 * @returns {{ ok: boolean, errors: string[] }}
 */
function validateUser(email, password) {
  const errors = [];

  if (typeof email !== "string" || email.trim().length === 0) {
    errors.push("email_required");
  } else {
    // Regex razonable (no pretende cubrir todos los casos RFC)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) errors.push("email_invalid");
  }

  if (typeof password !== "string" || password.length === 0) {
    errors.push("password_required");
  } else {
    if (password.length < 8) errors.push("password_too_short");
    if (!/[0-9]/.test(password)) errors.push("password_missing_number");
    if (!/[^A-Za-z0-9]/.test(password)) errors.push("password_missing_symbol");
  }

  return { ok: errors.length === 0, errors };
}

module.exports = { validateUser };
