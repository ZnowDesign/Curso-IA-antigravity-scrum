const request = require("supertest");
const { app, users } = require("../src/server");

describe("Users API", () => {
  beforeEach(() => {
    // reset in-memory store
    users.length = 0;
  });

  test("GET /users returns 200 and an array", async () => {
    const res = await request(app).get("/users");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("POST /users with valid payload returns 201", async () => {
    const res = await request(app)
      .post("/users")
      .send({ email: "dev@empresa.com", password: "Passw0rd!" });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("id");
    expect(res.body).toHaveProperty("email", "dev@empresa.com");
  });

  test("POST /users with invalid payload returns 400 and errors", async () => {
    const res = await request(app)
      .post("/users")
      .send({ email: "mal", password: "123" });

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("errors");
    expect(Array.isArray(res.body.errors)).toBe(true);
  });

  test("POST /users with missing payload fields returns 400", async () => {
    const res = await request(app).post("/users").send({});
    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("errors");
  });
});
