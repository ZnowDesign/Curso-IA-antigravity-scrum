const { validateUser } = require("../src/validators/validateUser");

describe("validateUser", () => {
  test("returns ok for valid email and strong password", () => {
    const r = validateUser("dev@empresa.com", "Passw0rd!");
    expect(r.ok).toBe(true);
    expect(r.errors).toEqual([]);
  });

  test("rejects invalid email", () => {
    const r = validateUser("mal", "Passw0rd!");
    expect(r.ok).toBe(false);
    expect(r.errors).toContain("email_invalid");
  });

  test("rejects too short password", () => {
    const r = validateUser("dev@empresa.com", "Pw0!");
    expect(r.ok).toBe(false);
    expect(r.errors).toContain("password_too_short");
  });

  test("rejects password without number", () => {
    const r = validateUser("dev@empresa.com", "Password!");
    expect(r.ok).toBe(false);
    expect(r.errors).toContain("password_missing_number");
  });

  test("rejects password without symbol", () => {
    const r = validateUser("dev@empresa.com", "Password1");
    expect(r.ok).toBe(false);
    expect(r.errors).toContain("password_missing_symbol");
  });

  test("rejects missing fields", () => {
    const r = validateUser("", "");
    expect(r.ok).toBe(false);
    expect(r.errors).toContain("email_required");
    expect(r.errors).toContain("password_required");
  });
});
